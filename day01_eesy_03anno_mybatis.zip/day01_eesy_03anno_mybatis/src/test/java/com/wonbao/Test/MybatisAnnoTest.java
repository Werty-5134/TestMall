package com.wonbao.Test;
import com.wonbao.dao.IUserDao;
import com.wonbao.domain.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.Date;
import java.util.List;

public class MybatisAnnoTest {

    private InputStream in;
    private SqlSession session;
    private IUserDao userDao;

    @Before
    public void init() throws Exception {
//        1.获取字节流输入流
//          生产SqlSessionFactory之前builder文件
//        2.根据字节流输入流构建SqlSessionFactory
//        3.根据SqlSessionFactory生产出一个SqlSession
//        4.使用SqlSession获取Dao的代理对象
//        5.执行Dao的方法

        in = Resources.getResourceAsStream("SqlMapConfig.xml");
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory factory = builder.build(in);
        session = factory.openSession(true);
        userDao = session.getMapper(IUserDao.class);
    }

    @After
    public void destroy() throws Exception {
        // 释放资源
//        session.commit();
        session.close();
        in.close();
    }

    @Test
    public void testFindAll() {
        List<User> users = userDao.findAll();
        for (User user : users) {
            System.out.println("-------每个用户信息-------");
            System.out.println(user);
        }
    }
    @Test
    public void testSaveUser() {
       User user = new User();
       user.setSex("男");
       user.setUsername("wuyifan");
       user.setBirthday(new Date());
       user.setAddress("加拿大");
       userDao.saveUser(user);
    }
    @Test
    public void testupdateUser() {
        User user = new User();
        user.setId(13);
        user.setSex("男");
        user.setUsername("update wuyifan");
        user.setBirthday(new Date());
        user.setAddress("加拿大");
        userDao.update(user);
    }
    @Test
    public void testdeleteUser() {
        userDao.delete(13);
    }
    @Test
    public void testfindAllid() {
        User user =  userDao.findAllid(10);
        System.out.println(user);
    }
    @Test
    public void testfindAlllike() {
        List<User> user =  userDao.findAlllike("%l%");
        for (User user1 : user) {
            System.out.println(user1);
        }
    }
}