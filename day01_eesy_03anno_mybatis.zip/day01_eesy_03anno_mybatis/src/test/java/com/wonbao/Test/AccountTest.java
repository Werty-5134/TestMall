package com.wonbao.Test;
import com.wonbao.dao.IAccountDao;
import com.wonbao.domain.Account;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

public class AccountTest {

    private InputStream in;
    private SqlSession session;
    private IAccountDao accountDao;

    @Before
    public void init() throws Exception {
//        1.获取字节流输入流
//          生产SqlSessionFactory之前builder文件
//        2.根据字节流输入流构建SqlSessionFactory
//        3.根据SqlSessionFactory生产出一个SqlSession
//        4.使用SqlSession获取Dao的代理对象
//        5.执行Dao的方法

        in = Resources.getResourceAsStream("SqlMapConfig.xml");
//        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
//        SqlSessionFactory factory = builder.build(in);
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(in);
        session = factory.openSession(true);
        accountDao = session.getMapper(IAccountDao.class);
    }

    @After
    public void destroy() throws Exception {
        // 释放资源
//        session.commit();
        session.close();
        in.close();
    }

    @Test
    public void testFindAll() {
        List<Account> accounts = accountDao.findAll();
        for (Account account : accounts) {
            System.out.println("-------每个用户信息-------");
            System.out.println(account);
            System.out.println(account.getUser());
        }
    }
}