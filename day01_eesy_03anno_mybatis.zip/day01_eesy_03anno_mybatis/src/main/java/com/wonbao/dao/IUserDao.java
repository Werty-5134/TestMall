package com.wonbao.dao;

import com.wonbao.domain.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface IUserDao {

    /**
     * 模糊查询所有用户
     * @return
     */
//    @Select(value = "select * from userinfo where username like '%${value}%' ")
    @Select(value = "select * from userinfo where username like #{username} ")
    List<User> findAlllike(String name);

    /**
     * 查询所有用户
     * @return
     */
    @Select(value = "select * from userinfo")
//    @ResultMap(value ={"userMap"})
//    实体类和数据库名不一样时 使用Results注解 使用ResultMap时可以多次使用在别的的地方
//    @Results(id = "userMap",value = {
//            @Result(id = true,column = "id",property = "userId"),
//            @Result(column = "username",property = "别名"),
//            @Result(column = "address",property = "别名"),
//            @Result(column = "sex",property = "别名"),
//            @Result(column = "birthday",property = "别名")
//    })
    List<User> findAll();

    /**
     * 根据id查询用户信息
     * @return
     */
    @Select(value = "select * from userinfo where id=#{id}")
//    @ResultMap(value ={"userMap"})
    User findAllid(Integer id);

    /**
     * 添加用户信息
     * @param user
     */
    @Insert(value = "insert into userinfo(username,address,sex,birthday) values(#{username},#{address},#{sex},#{birthday})")
    void saveUser(User user);

    /**
     * 修改用户信息
     * @param user
     */
    @Update(value = "update userinfo set username=#{username},address=#{address},sex=#{sex},birthday=#{birthday} where id=#{id}")
    void update(User user);

    /**
     * 删除用户信息
     * @param id
     */
    @Update(value = "delete from userinfo where id=#{id}")
    void delete(Integer id);
}
