package com.wonbao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// SpringBootApplication 标注一下这个是SpringBoot应用
@SpringBootApplication
public class Springboot01HelloworldApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot01HelloworldApplication.class, args);
	}

}
