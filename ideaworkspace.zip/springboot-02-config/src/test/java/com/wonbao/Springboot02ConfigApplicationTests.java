package com.wonbao;

import com.wonbao.pojo.Dog;
import com.wonbao.pojo.Person;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot02ConfigApplicationTests {

	@Autowired
//	@Qualifier 多个同类dog是可以指定是哪一个
	private Dog dog;

	@Autowired
	private Person person;
	@Test
	void contextLoads() {
		System.out.println(dog);
		System.out.println(person);
	}

}
