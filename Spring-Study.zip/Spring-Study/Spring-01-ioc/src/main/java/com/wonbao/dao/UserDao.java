package com.wonbao.dao;

public interface UserDao {
    void getUser();
}
