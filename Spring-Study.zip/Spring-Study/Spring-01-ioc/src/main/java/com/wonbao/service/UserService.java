package com.wonbao.service;

public interface UserService {
    void getUser();
}
