import com.wonbao.Mapper.mapper;
import com.wonbao.pojo.admin;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTest {

    @Test
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        mapper mapperImpl = context.getBean("mapperImpl", mapper.class);
        for (admin admin : mapperImpl.select()) {
            System.out.println(admin);
        }
    }
}
