package com.wonbao.Mapper;

import com.wonbao.pojo.admin;
import org.mybatis.spring.SqlSessionTemplate;

import java.util.List;

public class mapperImpl implements mapper {

    private SqlSessionTemplate sqlSession;

    public void setSqlSession(SqlSessionTemplate sqlSession) {
        this.sqlSession = sqlSession;
    }

    @Override
    public List<admin> select() {
        mapper mapper = sqlSession.getMapper(mapper.class);
        return mapper.select();
    }
}
