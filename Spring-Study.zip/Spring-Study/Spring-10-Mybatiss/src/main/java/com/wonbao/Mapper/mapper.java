package com.wonbao.Mapper;

import com.wonbao.pojo.admin;

import java.util.List;

public interface mapper {

    public List<admin> select();
}
