import com.wonbao.pojo.UserInfo;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTest {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationCotext.xml");
        UserInfo user = (UserInfo) context.getBean("newuser");
        System.out.println(user);
    }
}
