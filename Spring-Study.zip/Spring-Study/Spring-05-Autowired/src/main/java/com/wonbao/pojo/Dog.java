package com.wonbao.pojo;

public class Dog {
    public void shout()
    {
        System.out.println("wang~~~");
    }
}
