package com.wonbao.demo03;

public class Client {
    public static void main(String[] args) {
        Host host = new Host();
        ProxyInvocationHandler pin = new ProxyInvocationHandler();
        pin.setRent(host);
        Rent rent = (Rent) pin.getProxy();
        rent.rent();
    }
}
