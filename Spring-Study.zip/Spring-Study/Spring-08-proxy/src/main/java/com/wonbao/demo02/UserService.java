package com.wonbao.demo02;

public interface UserService {

    public void add();
    public void delete();
    public void update();
    public void query();
}
