package com.wonbao.demo03;

public interface Rent {
    public void rent();
}
