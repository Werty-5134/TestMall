package com.wonbao.demo04;

import com.wonbao.demo02.UserService;
import com.wonbao.demo02.UserServiceImpl;

public class Client {
    public static void main(String[] args) {
        UserServiceImpl userService = new UserServiceImpl();

        ProxyInvocationHandler pin = new ProxyInvocationHandler();
        pin.setTarget(userService);
        UserService proxy = (UserService) pin.getProxy();
        proxy.add();
    }
}
