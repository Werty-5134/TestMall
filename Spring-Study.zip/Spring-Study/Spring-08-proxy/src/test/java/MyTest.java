import com.wonbao.demo02.UserServiceImpl;

public class MyTest {
    public static void main(String[] args) {
        UserServiceImpl service = new UserServiceImpl();
        service.add();
    }
}
