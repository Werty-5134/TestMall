import com.wonbao.mappers.UserMapperPlus;
import com.wonbao.pojo.UserInfoPlus;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;
import java.util.List;

public class MyTest {

    @Test
    public void newtestPlus() throws IOException {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        UserMapperPlus userMapperPlus = context.getBean("userMapperPlus", UserMapperPlus.class);
        List<UserInfoPlus> userInfoPluses = userMapperPlus.selectUserInfoPlus();
        for (UserInfoPlus userInfoPlus : userInfoPluses) {
            System.out.println(userInfoPlus);
        }
    }
}