package com.wonbao.mappers;

import com.wonbao.pojo.UserInfoPlus;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import java.util.List;

public class UserMapperPlusImpl extends SqlSessionDaoSupport implements UserMapperPlus{

    @Override
    public List<UserInfoPlus> selectUserInfoPlus() {
        UserInfoPlus userInfoPlus = new UserInfoPlus();
        userInfoPlus.setUserid(10);
        userInfoPlus.setUsername("lzl");
        userInfoPlus.setUserpwd("123456");
        UserMapperPlus mapper = getSqlSession().getMapper(UserMapperPlus.class);

        mapper.addUser(userInfoPlus);
        mapper.deleteUser(9);
        return mapper.selectUserInfoPlus();
    }

    @Override
    public int addUser(UserInfoPlus userInfoPlus) {
        return getSqlSession().getMapper(UserMapperPlus.class).addUser(userInfoPlus);
    }

    @Override
    public int deleteUser(int userid) {
        return getSqlSession().getMapper(UserMapperPlus.class).deleteUser(userid);
    }
}
