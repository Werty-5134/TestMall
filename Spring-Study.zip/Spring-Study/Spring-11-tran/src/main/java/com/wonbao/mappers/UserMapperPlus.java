package com.wonbao.mappers;

import com.wonbao.pojo.UserInfoPlus;

import java.util.List;

public interface UserMapperPlus {
    public List<UserInfoPlus> selectUserInfoPlus();

    public int addUser(UserInfoPlus userInfoPlus);

    public int deleteUser(int userid);
}
