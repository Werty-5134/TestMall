package com.wonbao.pojo;

public class UserInfo {
    private String age;
    private String name;

    public UserInfo(String age, String name) {
        this.age = age;
        this.name = name;
    }
    public UserInfo() {
    }
    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "UserInfo{" +
                "age='" + age + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
