import com.wonbao.pojo.UserInfo;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTest {
    public static void main(String[] args) {
//        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
//        Student student = (Student) context.getBean("student");
//        System.out.println(student.toString());
//        scope="singleton" 默认单例模式机制 从配置中只拿一次值
//        scope="prototype" 原型模式 每一次Get时都会创建一次 产生一个新的对象
//        request session application 只有在web里才可以使用 请求一次失效 一直存在会话中 全局中
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        UserInfo user = context.getBean("user2", UserInfo.class);
        System.out.println(user);
    }
}
