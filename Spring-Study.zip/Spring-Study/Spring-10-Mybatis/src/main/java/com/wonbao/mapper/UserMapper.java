package com.wonbao.mapper;

import com.wonbao.pojo.userInfo;

import java.util.List;

public interface UserMapper {

    public List<userInfo> select();
}
