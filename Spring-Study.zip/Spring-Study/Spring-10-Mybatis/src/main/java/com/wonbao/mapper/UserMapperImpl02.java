package com.wonbao.mapper;

import com.wonbao.pojo.userInfo;
import org.apache.ibatis.session.SqlSession;
import org.mybatis.spring.support.SqlSessionDaoSupport;

import java.util.List;

public class UserMapperImpl02 extends SqlSessionDaoSupport implements UserMapper {

    @Override
    public List<userInfo> select() {
        SqlSession session = getSqlSession();
        UserMapper mapper = session.getMapper(UserMapper.class);
        return mapper.select();
    }
}
