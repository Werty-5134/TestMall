import com.wonbao.mapper.UserMapper;
import com.wonbao.pojo.userInfo;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;

public class MyTest {

    @Test
    public void newtest() throws IOException {
//        InputStream in = Resources.getResourceAsStream("mybatis-config.xml");
//        SqlSessionFactory sessionFactory = new SqlSessionFactoryBuilder().build(in);
//        SqlSession sqlSession = sessionFactory.openSession(true);
//
//        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
//        List<userInfo> list = mapper.select();
//        for (userInfo user : list) {
//            System.out.println(user);
//        }
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        UserMapper userMapper = context.getBean("userMapper2", UserMapper.class);
        for (userInfo userInfo : userMapper.select()) {
            System.out.println(userInfo);
        }
    }
}