package com.wonbao.diy;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

//标注为是一个切面
@Aspect
public class AnnoDiy {

    @Before("execution(* com.wonbao.service.UserServiceImpl.*(..))")
    public void before(){
        System.out.println("方法执行之前！！！");
    }

    @After("execution(* com.wonbao.service.UserServiceImpl.*(..))")
    public void after(){
        System.out.println("方法执行之后！！！");
    }
}
