package com.wonbao.service;

public class UserServiceImpl implements UserService {
    @Override
    public void add() {
        System.out.println("add了一个用户信息!!!!");
    }

    @Override
    public void delete() {
        System.out.println("delete了一个用户信息!!!!");
    }

    @Override
    public void update() {
        System.out.println("update了一个用户信息!!!!");
    }

    @Override
    public void query() {
        System.out.println("query了一个用户信息!!!!");
    }
}