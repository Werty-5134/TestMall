import com.wonbao.service.UserService;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTEST {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        UserService userService = context.getBean("userService", UserService.class);
        userService.add();
    }
}
