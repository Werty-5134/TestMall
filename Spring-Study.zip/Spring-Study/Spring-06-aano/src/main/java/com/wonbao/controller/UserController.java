package com.wonbao.controller;

import org.springframework.stereotype.Controller;

@Controller
public class UserController {
}
