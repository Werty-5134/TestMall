package com.wonbao.pojo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//等价于 <bean id="user" class="com.wonbao.pojo.User"/>
@Component
@Scope("prototype")
public class User {

//    public String name = "旺店宝";
    public String name = "旺店宝";
    @Value("旺店宝")
    public void setName(String name) {
        this.name = name;
    }
}
