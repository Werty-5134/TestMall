package com.wonbao.Test;

import com.wonbao.dao.IRoleDao;
import com.wonbao.dao.IUserDao;
import com.wonbao.domain.Role;
import com.wonbao.domain.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

public class RoleTest {

    private InputStream in;
    private SqlSession session;
    private IRoleDao roleDao;

    @Before
    public void init() throws Exception {
        // 读取配置文件
        in = Resources.getResourceAsStream("SqlMapConfig.xml");
        // 创建SqlsessionFacatory
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory factory = builder.build(in);
        // 使用工厂生成Sqlsession
        // openSession true为自动提交
        session = factory.openSession(true);
        // 使用Sqlsession创建dao接口代理对象
        roleDao = session.getMapper(IRoleDao.class);
    }

    @After
    public void destroy() throws Exception {
        // 释放资源
//        session.commit();
        session.close();
        in.close();
    }

    @Test
    public void testFindAll() {
        List<Role> roles = roleDao.findAll();
        for (Role role : roles) {
            System.out.println("------每个角色的信息-----");
            System.out.println(role);
            System.out.println(role.getUsers());
        }
    }
}