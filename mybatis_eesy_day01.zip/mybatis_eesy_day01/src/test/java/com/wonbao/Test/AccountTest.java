package com.wonbao.Test;

import com.wonbao.dao.IAccountDao;
import com.wonbao.dao.IUserDao;
import com.wonbao.domain.Account;
import com.wonbao.domain.AccountUser;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.List;

public class AccountTest {

    private InputStream in;
    private SqlSession session;
    private IAccountDao iAccountDao;
    @Before
    public void init() throws Exception {
        // 读取配置文件
        in = Resources.getResourceAsStream("SqlMapConfig.xml");
        // 创建SqlsessionFacatory
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory factory = builder.build(in);
        // 使用工厂生成Sqlsession
        // openSession true为自动提交
        session = factory.openSession(true);
        // 使用Sqlsession创建dao接口代理对象
        iAccountDao = session.getMapper(IAccountDao.class);
    }
    @After
    public void destroy() throws Exception{
        // 释放资源
//        session.commit();
        session.close();
        in.close();
    }
    @Test
    public void testFindAll(){
        List<Account> accountDaos = iAccountDao.findAll();
        for (Account accountDao : accountDaos) {
            System.out.println("------每一个account------");
            System.out.println(accountDao);
            System.out.println(accountDao.getUser());
        }
    }
    @Test
    public void testfindAllAccount(){
        List<AccountUser> accountDaos = iAccountDao.findAllAccount();
        for (AccountUser accountDao : accountDaos) {
            System.out.println(accountDao);
        }
    }
}
