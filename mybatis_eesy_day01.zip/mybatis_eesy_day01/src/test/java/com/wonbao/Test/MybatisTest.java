package com.wonbao.Test;

import com.wonbao.dao.IUserDao;
import com.wonbao.domain.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

public class MybatisTest {

    private InputStream in;
    private SqlSession session;
    private IUserDao userDao;
    @Before
    public void init() throws Exception {
        // 读取配置文件
        in = Resources.getResourceAsStream("SqlMapConfig.xml");
        // 创建SqlsessionFacatory
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory factory = builder.build(in);
        // 使用工厂生成Sqlsession
        session = factory.openSession();
        // 使用Sqlsession创建dao接口代理对象
        userDao = session.getMapper(IUserDao.class);
    }
    @After
    public void destroy() throws Exception{
        // 释放资源
        session.commit();
        session.close();
        in.close();
    }
    @Test
    public void testFindAll() {
        List<User> users = userDao.findAll();
        for (User user : users){
            System.out.println(user);
        }
    }
    @Test
    public void testsaveUser() {
        User user = new User();
        user.setUsername("liuziliang");
        user.setAddress("北京市");
        user.setSex("男");
        user.setBirthday(new Date());
        System.out.println("qian:"+user);
        userDao.saveUser(user);
        System.out.println("hou:"+user);
    }

    @Test
    public void testupdateUser() {
        User user = new User();
        user.setId(6);
        user.setUsername("mybatis update userinfo");
        user.setAddress("汕头市");
        user.setSex("男");
        user.setBirthday(new Date());
        userDao.updateUser(user);
    }

    @Test
    public void testdeleteUser() {
        userDao.deleteUser(7);
    }






















}
