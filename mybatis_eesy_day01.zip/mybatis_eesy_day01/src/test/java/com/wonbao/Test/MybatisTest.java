package com.wonbao.Test;

import com.wonbao.dao.IUserDao;
import com.wonbao.dao.WonbaoStudy;
import com.wonbao.domain.QueryVo;
import com.wonbao.domain.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MybatisTest {

    private InputStream in;
    private SqlSession session;
    private IUserDao userDao;
    @Before
    public void init() throws Exception {
        // 读取配置文件
        in = Resources.getResourceAsStream("SqlMapConfig.xml");
        // 创建SqlsessionFacatory
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory factory = builder.build(in);
        // 使用工厂生成Sqlsession
        // openSession true为自动提交
        session = factory.openSession(true);
        // 使用Sqlsession创建dao接口代理对象
        userDao = session.getMapper(IUserDao.class);
    }
    @After
    public void destroy() throws Exception{
        // 释放资源
//        session.commit();
        session.close();
        in.close();
    }
    /*@Test
    public void testFindAll() {
        List<User> users = userDao.findAll();
        for (User user : users){
            System.out.println(user);
        }
    }
    @Test
    public void testsaveUser() {
        User user = new User();
        user.setUsername("autocommmit");
        user.setAddress("北京市");
        user.setSex("男");
        user.setBirthday(new Date());
        System.out.println("qian:"+user);
        userDao.saveUser(user);
        System.out.println("hou:"+user);
    }

    @Test
    public void testupdateUser() {
        User user = new User();
        user.setId(6);
        user.setUsername("mybatis update userinfo");
        user.setAddress("汕头市");
        user.setSex("男");
        user.setBirthday(new Date());
        userDao.updateUser(user);
    }

    @Test
    public void testdeleteUser() {
        userDao.deleteUser(7);
    }

    @Test
    public void testfindid() {
        User user = userDao.findid(3);
        System.out.println(user);
    }

    @Test
    public void testfindUserByConditin() {
        User u = new User();
        u.setUsername("liuziliang");
        u.setSex("女");
        List<User> users = userDao.findUserByConditin(u);
        for (User user : users){
            System.out.println(user);
        }
    }

    @Test
    public void testfindUserInIds() {
        QueryVo vo = new QueryVo();
        List<Integer> list = new ArrayList<Integer>();
        list.add(3);
        list.add(4);
        list.add(8);
        vo.setIds(list);
        List<User> users = userDao.findUserInIds(vo);
        for (User user : users){
            System.out.println(user);
        }
    }

    @Test
    public void testconvertMD5(){
        String inStr = "1522044762";
        String num =  WonbaoStudy.convertMD5(inStr);
        System.out.println(num);
        String num1 = WonbaoStudy.convertMD5(WonbaoStudy.convertMD5(num));
        System.out.println(num1);
    }*/





















}
