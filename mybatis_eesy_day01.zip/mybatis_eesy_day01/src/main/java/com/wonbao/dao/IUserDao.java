package com.wonbao.dao;

import com.wonbao.domain.User;

import java.util.List;

/**
 * 用户的持久层接口
 * @author : lzl
 * @Date : 2021/5/25 23:27
 */
public interface IUserDao {

    /**
     * 查询所有的接口
     * @return
     */
    List<User> findAll();
}
