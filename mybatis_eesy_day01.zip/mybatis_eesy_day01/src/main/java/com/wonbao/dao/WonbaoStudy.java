package com.wonbao.dao;

import javax.persistence.Column;
import java.lang.reflect.Method;

public class WonbaoStudy {

    /**
     * 获取实体类的字段集
     * @param entityClass
     * @return
     */
    public static String createSelectFields(Class<?> entityClass) {
        Method[] ms = entityClass.getDeclaredMethods();
        StringBuilder fieldBuilder = new StringBuilder();
        for (Method method : ms) {
            if (isBeanGetMethod(method)) {
                Column column = getMethodColumn(method);
                if (column != null) {
                    fieldBuilder.append(column.name()).append(",");
                }
            }
        }
        if (fieldBuilder.length() > 0) {
            fieldBuilder.deleteCharAt(fieldBuilder.length() - 1);
        }
        return fieldBuilder.toString();
    }

    public static Column getMethodColumn(Method method) {
        return method.getAnnotation(Column.class);
    }

    /**
     * 判断方法是否为实体的get方法
     * @param method
     * @return
     */
    public static boolean isBeanGetMethod(Method method) {
        String primaryKey = "primaryKey";
        if (method.getModifiers() == 1 && method.getName().indexOf("get") == 0 && !method.getName().equals(primaryKey) && method.getReturnType().getName() != "void") {
            return true;
        }
        return false;
    }

    /**
     * 组建where in (?,?,?) 预编译语段
     * @param count
     * @return
     */
    public static String whereToin(int count){
        StringBuilder stringBuilder = new StringBuilder("(");
        for (int i = 0 ; i < count; i++){
            stringBuilder.append("?").append(",");
        }
        stringBuilder.setCharAt(stringBuilder.length()-1,')');
        return stringBuilder.toString();
    }

    /**
     * 加减乘除任意输入数字做计算
     * @param b 参数
     * @return
     */
    public static int mul(int...b) {
        int sum = 1;
        for (int x : b) {
            sum *= x;
        }
        return sum;
    }
}
